using System;

{
	public Class1()
	{
	}
}
